/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/11 22:44:53 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/13 16:19:40 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void	ft_putnbr(int nb);

int main(int argc, char **argv)
{
	if (argc == 2)
		ft_putnbr(atoi(*(argv + 1)));
	return (0);
}
