/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/13 16:37:47 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/13 16:50:20 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_program_name(char **c)
{
	int i;

	i = 0;
	while (c[0][i] != '\0')
	{
		ft_putchar(c[0][i]);
		i++;
	}
	ft_putchar('\n');
}

int		main(int argc, char **argv)
{
	if (argc == 1)
		ft_print_program_name(argv);
	return (0);
}
