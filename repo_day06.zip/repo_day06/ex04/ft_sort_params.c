/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/13 17:06:17 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/13 18:48:37 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print(char **c, int x)
{
	int i;

	i = 0;
	while (c[x][i] != '\0')
	{
		ft_putchar(c[x][i]);
		i++;
	}
	ft_putchar('\n');
}

int		ft_strcmp(char *s1, char *s2)
{
	int i;

	i = 0;
	if (s1[0] != '\0' || s2[0] != '\0')
	{
		while (s1[i] == s2[i])
		{
			if (s1[i] == '\0' && s2[i] == '\0')
				return (0);
			i++;
		}
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
	}
	return (0);
}

void	sort(char **argv, int argc)
{
	char *s;
	int i;
	int j;

	i = 0;
	while (i < argc)
	{
		j = 1;
		while (j < argc - 1)
		{
			if (ft_strcmp(*(argv + j + 1), *(argv + j)) <= 0)
			{
				s = *(argv + j + 1);
				*(argv + j + 1) = *(argv + j);
				*(argv + j) = s;
			}
			j++;
		}
		i++;
	}
}


int		main(int argc, char **argv)
{
	int i;

	i = 0;
	sort(argv, argc);
	i = 1;
	while (i < argc)
	{
		ft_print(argv, i);
		i++;
	}
	return (0);
}
