/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/13 16:49:40 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/13 17:04:28 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_program_name(char **c, int x)
{
	int i;

	i = 0;
	while (c[x][i] != '\0')
	{
		ft_putchar(c[x][i]);
		i++;
	}
	ft_putchar('\n');
}

int		main(int argc, char **argv)
{
	int i;

	i = 0;
	while (i < argc)
	{
		ft_print_program_name(argv, i);
		i++;
	}
	return (0);
}
