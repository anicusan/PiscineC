gcc -c *.c
ar rc libft.a *o
