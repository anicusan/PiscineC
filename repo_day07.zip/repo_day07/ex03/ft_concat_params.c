/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 20:41:20 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 21:01:50 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_concat_params(int argc, char **argv)
{
	char	*concatenated;
	int		size;
	int		i;
	int		j;

	i = 0;
	size = 0;
	while (++i < argc)
	{
		j = -1;
		while (argv[i][++j] != '\0')
			size++;
	}
	concatenated = (char*)malloc(sizeof(*concatenated) * (size + argc - 1));
	i = 0;
	size = 0;
	while (++i < argc)
	{
		j = -1;
		while (argv[i][++j] != '\0')
			concatenated[size++] = argv[i][j];
		concatenated[size++] = '\n';
	}
	concatenated[size] = '\0';
	return (concatenated);
}
