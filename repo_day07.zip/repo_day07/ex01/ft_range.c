/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/13 22:15:12 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/13 22:22:38 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		*ft_range(int min, int max)
{
	int *v;
	int i;

	if (min >= max)
		return (NULL);
	else
	{
		v = malloc(4 * (max - min));
		i = 0;
		while (i < (max - min))
		{
			v[i] = min + i;
			i++;
		}
		return (v);
	}
}
