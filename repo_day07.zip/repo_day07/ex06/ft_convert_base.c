/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 21:46:00 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 22:08:52 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libft.h>

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}

void	ft_nbr_base_str(int nbr, char *base, char *str) 
{
	int	lbase;
	lbase = ft_strlen(base);

	if (nbr < 0)
	{
		ft_strcat(str, "-");
		nbr *= -1;
	}

	if (nbr > lbase - 1)
	{
		ft_nbr_base_str(nbr/lbase, base, str);
		ft_nbr_base_str(nbr%lbase, base, str);
	}
	else
		ft_strncat(str, &base[nbr], 1);
}

int	ft_atoi_base(char *str, int base)
{
	int	value;
	int	sign;

	value = 0;
	if (base <= 1 || base > 36)
		return (0);
	while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\f'
			|| *str == '\r' || *str == '\v')
		str++;
	sign = (*str == '-') ? -1 : 1;
	if (*str == '-' || *str == '+')
		str++;
	while (ft_inbase(*str, base))
	{
		if (*str - 'A' >= 0)
			value = value * base + (*str - 'A' + 10);
		else
			value = value * base + (*str - '0');
		str++;
	}
	return (value * sign);
}

int			ft_strlen(char *str)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	char	*str;
	int		dec;
	int		max;
	int		base_to_length;
	int		count;

	dec = ft_atoi_base(nbr, base_from);
	base_to_length = ft_strlen(base_to);
	max = 1;
	count = 1;
	while (max <= dec)
	{
		max = max * base_to_length;
		count++;
	}
	str = malloc(sizeof(char) * (count + 1));
	if (str == NULL)
		return (0);
	ft_nbr_base_str(dec, base_to, &(*str));
	ft_putstr(str);
	return (nbr);
}
