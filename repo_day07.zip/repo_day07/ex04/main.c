/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 22:23:04 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 22:27:20 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	**ft_split_whitespaces(char *str);

int		main(int argc, char **argv)
{
	int i;
	char **s;

	i = 0;
	if (argc == 2)
	{
		s = ft_split_whitespaces(argv[1]);
		while (s[i] != NULL)
		{
			printf("%s \n", s[i]);
			i++;
		}
	}
	return (0);
}
