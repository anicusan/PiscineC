/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespace.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 21:34:15 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 22:33:53 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		verif(char c)
{
	if (c == ' ' || c == '	' || c == '\n')
		return (1);
	return (0);
}

void	wra(char *str, int i, int j, char *fin)
{
	int k;

	k = 0;
	while (i < j && verif(str[i]) == 0)
	{
		fin[k] = str[i];
		k++;
		i++;
	}
	if (verif(str[i]) == 0)
		fin[k] = '\0';
}

int		count(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int		exe(int i, char *str)
{
	while (verif(str[i]) == 1)
		i++;
	return (i);
}

char	**ft_split_whitespaces(char *str)
{
	int		i;
	int		j;
	int		x;
	char	**fin;

	x = 0;
	i = exe(0, str);
	j = i;
	fin = (char**)malloc(count(str) * count(str) * 4);
	*fin = malloc(count(str) * 2);
	while (str[j] != '\0')
	{
		if (verif(str[j]) == 1)
		{
			wra(str, i, j, *(fin + x++));
			i = exe(j, str);
			*(fin + x) = malloc(count(str) * 2);
			j = i - 1;
		}
		j++;
	}
	if (i != j)
		wra(str, i, j, *(fin + x++));
	fin[x] = NULL;
	return (fin);
}
