/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 19:27:09 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 21:23:04 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strdup(char *src);

int		main(int argc, char **argv)
{
	char *s;

	if (argc == 2)
	{
		s = ft_strdup(argv[1]);
		printf("%s\n", argv[1]);
		printf("%s", argv[1]);
	}
	return (0);
}
