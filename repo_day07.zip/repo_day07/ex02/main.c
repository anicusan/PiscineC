/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 20:04:13 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 20:33:44 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int		ft_ultimate_range(int **range, int min, int max);

int		main(void)
{
	int **s;
	int i;
	int x;

	s = (int**)malloc(8 * 19);
	x = ft_ultimate_range(s ,5, 24);
	i = 0;
	while (i <= 19)
	{
		printf("%d ", s[0][i]);
		i++;
	}
	printf("%d", x);
	return (0);
}
