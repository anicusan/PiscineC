/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 19:47:27 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/14 20:31:55 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_ultimate_range(int **range, int min, int max)
{
	int *v;
	int i;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	else
	{
		v = malloc(4 * (max - min));
		i = 0;
		while (i < (max - min))
		{
			v[i] = min + i;
			i++;
		}
		*range = v;
		return (sizeof(range));
	}
}
