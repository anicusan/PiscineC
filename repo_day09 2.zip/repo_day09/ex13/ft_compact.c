/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_compact.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 16:34:39 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 16:49:12 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(char **s1, char **s2)
{
	char *aux;

	aux = *s1;
	*s1 = *s2;
	*s2 = aux;
}

void	dl(char **tab, int pos, int *length)
{
	while (pos < *length - 1)
	{
		ft_swap(&(tab[pos]), &(tab[pos + 1]));
		pos++;
	}
	*len = *len - 1;
}

int		ft_compact(char **tab, int length)
{
	int i;
	int j;
	int k;

	i = 0;
	while (i < length)
	{
		if (*(tab + i) == (char*)0)
			dl(tab, i, &length);
	}
	return (length);
}
