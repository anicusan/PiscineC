/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 03:08:25 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 11:28:37 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	ft_destroy(char **factory);

int		main(void)
{
	char **factory;

	factory = (char**)malloc(30);
	*factory = "plop";
	*(factory + 1) = "jayzus";
	*(factory + 2) = "aolo";
	*(factory + 3) = NULL;
	printf("1 %s \n2  %s \n3  %s \n", *factory, *(factory + 1), *(factory + 2));
	ft_destroy (factory);
	if (*factory == NULL)
		printf("ezaaz");
	//else
	//	printf("%s", *factory);
	return (0);
}
