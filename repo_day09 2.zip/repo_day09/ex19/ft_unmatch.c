/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unmatch.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 17:14:34 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 17:19:07 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_unmatch(int *tab, int length)
{
	int i;
	int j;
	int k;

	j = 0;
	while (j < length)
	{
		i = 0;
		k = 0;
		while (i < length)
		{
			if (i != j)
				if (tab[i] == tab[j])
				{
					k = 1;
					break ;
				}
			i++;
		}
		if (k != 0)
			return (tab[j]);
		j++;
	}
	return (tab[j]);
}
