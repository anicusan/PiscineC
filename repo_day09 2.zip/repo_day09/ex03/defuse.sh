touch -A -01 bomb.txt
stat -f "%m" -t "%s" bomb.txt
