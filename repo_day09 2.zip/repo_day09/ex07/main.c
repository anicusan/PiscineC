/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 12:30:28 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 12:50:07 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_collatz_conjecture(unsigned int base);

int				main(void)
{
	unsigned int base;

	base = 1234567887;
	printf("%d", ft_collatz_conjecture(base));
	return (0);
}
