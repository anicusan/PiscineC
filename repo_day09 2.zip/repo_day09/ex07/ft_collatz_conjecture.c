/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_collatz_conjecture.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 12:10:26 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 12:38:47 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void			fcc(long long bs, long long *i)
{
	if (bs % 2 == 0)
	{
		i[0]++;
		fcc(bs / 2, i);
	}
	if (bs % 2 == 1 && bs != 1)
	{
		i[0]++;
		fcc(bs * 3 + 1, i);
	}
}

unsigned int	ft_collatz_conjecture(unsigned int base)
{
	long long i[1];

	i[0] = 0;
	if (base > 1)
		fcc((long long)base, i);
	return ((unsigned int)i[0]);
}
