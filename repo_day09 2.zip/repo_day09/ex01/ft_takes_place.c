/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 22:54:11 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 02:27:15 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	rwa(int h1, int h2)
{
	printf("THE FOLLOWING TAKES PLACE BETWEEN %d.00 ", h1 / 10);
	if (h1 % 10 == 0)
		printf("A.M AND %d.00 ", h2 / 10);
	else
		printf("P.M AND %d.00 ", h2 / 10);
	if (h2 % 10 == 0)
		printf("A.M.");
	else
		printf("P.M.");
}

void	ft_takes_place(int hour)
{
	int h1;
	int h2;

	h1 = 0;
	h2 = 0;
	if (hour == 0 || hour == 24)
		h1 = 120;
	else if (hour > 0 && hour < 12)
		h1 = hour * 10;
	else if (hour == 12)
		h1 = 121;
	else if (hour > 12 && hour < 24)
		h1 = (hour - 12) * 10 + 1;
	if (h1 == 120)
		h2 = 10;
	else if (h1 == 110)
		h2 = 121;
	else if (h1 == 121)
		h2 = 11;
	else if (h1 == 111)
		h2 = 120;
	else
		h2 = h1 + 10;
	rwa(h1, h2);
}
