/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 12:54:17 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 14:06:47 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		verif(char c)
{
	if (c == ' ' || c == '	' || c == '\n' || c == '\0')
		return (1);
	return (0);
}

char	*ft_strstr(char *str, char *to_find)
{
	int x;
	int y;
	int z;

	x = 0;
	z = 0;
	if (*(to_find) == '\0')
		return (str);
	while (*(str + x) != '\0')
	{
		y = x;
		z = 0;
		if (x == 0 || verif(str[x - 1]) == 1)
			while (*(str + y) == *(to_find + z) ||
				*(str + y) == *(to_find + z) - 32)
			{
				y++;
				z++;
				if (*(to_find + z) == '\0' && verif(str[y]) == 1)
					return ((str + z));
			}
		x++;
	}
	return (0);
}

int		main(int argc, char **argv)
{
	int i;

	if (argc > 1)
	{
		i = 1;
		while (i < argc)
		{
			if (ft_strstr(argv[i], "president") != 0 ||
					ft_strstr(argv[i], "attack") != 0 ||
					ft_strstr(argv[i], "powers") != 0)
			{
				write(1, "Alert!!!\n", 9);
				return (0);
			}
			i++;
		}
	}
	return (0);
}
