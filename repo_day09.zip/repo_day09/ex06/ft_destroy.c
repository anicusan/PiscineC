/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_destroy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anicusan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 03:03:32 by anicusan          #+#    #+#             */
/*   Updated: 2016/07/15 03:39:58 by anicusan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include "ft_ultimator.h"
#include <stdlib.h>

void	ft_destroy(char **factory)
{
	int i;

	i = 0;
	while (i < 3)
	{
		free(*(factory + i));
		i++;
	}
	free(factory);
}
