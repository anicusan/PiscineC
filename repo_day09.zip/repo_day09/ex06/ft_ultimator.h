fndef __FT_ULTIMATOR_H__
# define __FT_ULTIMATOR_H__
/*
 * **
 * ** Cu Windows VISTA, a fost pe marginea prapastiei.
 * ** Cu Windows 8, s-a facut un mare pas inainte
 * **
 * ** Clientul: 'Am un PC cu Windows 8'
 * ** Tehnicianul: 'Da...'
 * ** Clientul: 'Si apoi PC-ul meu nu mai functioneaza'
 * ** Tehnicianul: 'Da, mi-ai mai spus-o deja'...
 * ** */
#endif

